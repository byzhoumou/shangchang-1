// postcss.config.js
// postcss.config.js
module.exports = {
  plugins: [require("autoprefixer")],
};
